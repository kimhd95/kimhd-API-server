'use strict';

let productionConfig = {
	env: 'production',
	hostname: 'localhost',
	port: 80,
	token_domain: '.jellylab.io',
};

module.exports = productionConfig;
