'use strict';

let devConfig = {
	env: 'dev',
	hostname: 'localhost',
	port: 5000,
	token_domain: 'localhost',
};

module.exports = devConfig;
